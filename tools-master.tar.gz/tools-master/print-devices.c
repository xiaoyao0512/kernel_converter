#include "cl-helper.h"

int main(int argc, char **argv)
{
  print_platforms_devices();
  return 0;
}
